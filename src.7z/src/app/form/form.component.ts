import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent {
  // fName: any;
  // lName: any;
  // option: string[] = ['Phone', 'Email'];
  // opt:any= phone;

  // submitForm() {
  //   console.log('Form submitted!');
  //   console.log('fName:', this.fName);
  //   console.log('lName:', this.lName);
  //   console.log('option:', this.option);
  // }
  myForm: FormGroup;
  options = [
    { value: 'option1', label: 'Option 1' },
    { value: 'option2', label: 'Option 2' },
    { value: 'option3', label: 'Option 3' }
  ];

  constructor() {
    this.myForm = new FormGroup({
      selectedOption: new FormControl('option2') // Set the default selected option
    });
  }
}
